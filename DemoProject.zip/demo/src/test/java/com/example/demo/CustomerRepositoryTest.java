package com.example.demo;

import com.example.demo.entity.Customer;
import com.example.demo.repository.CustomerRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@DisplayName("Customer Repository Tests")
class CustomerRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private CustomerRepository customerRepository;

    private Customer testCustomer;

    @BeforeEach
    void setUp() {
        testCustomer = new Customer();
        testCustomer.setName("John Doe");
        testCustomer.setEmail("john@example.com");
        testCustomer.setPhone("1234567890");
        testCustomer.setAge(30);
    }

    @Test
    @DisplayName("Should save customer successfully")
    void saveCustomer_WithValidData_ReturnsSavedCustomer() {
        // Act
        Customer saved = customerRepository.save(testCustomer);

        // Assert
        assertThat(saved).isNotNull();
        assertThat(saved.getId()).isNotNull();
        assertThat(saved.getName()).isEqualTo("John Doe");
        assertThat(saved.getEmail()).isEqualTo("john@example.com");
        assertThat(saved.getAge()).isEqualTo(30);
    }

    @Test
    @DisplayName("Should find customer by ID")
    void findById_ExistingCustomer_ReturnsCustomer() {
        // Arrange
        Customer saved = entityManager.persistAndFlush(testCustomer);

        // Act
        Optional<Customer> found = customerRepository.findById(saved.getId());

        // Assert
        assertThat(found).isPresent();
        assertThat(found.get().getName()).isEqualTo("John Doe");
    }

    @Test
    @DisplayName("Should return empty for non-existing ID")
    void findById_NonExistingCustomer_ReturnsEmpty() {
        // Act
        Optional<Customer> found = customerRepository.findById(999L);

        // Assert
        assertThat(found).isEmpty();
    }

    @Test
    @DisplayName("Should find all customers")
    void findAll_MultipleCustomers_ReturnsAllCustomers() {
        // Arrange
        Customer customer2 = new Customer(null, "Jane Doe", "jane@example.com", "9876543210", 25);
        entityManager.persistAndFlush(testCustomer);
        entityManager.persistAndFlush(customer2);

        // Act
        List<Customer> customers = customerRepository.findAll();

        // Assert
        assertThat(customers).hasSize(2);
        assertThat(customers).extracting(Customer::getName)
                .containsExactlyInAnyOrder("John Doe", "Jane Doe");
    }

    @Test
    @DisplayName("Should update customer successfully")
    void updateCustomer_ExistingCustomer_UpdatesFields() {
        // Arrange
        Customer saved = entityManager.persistAndFlush(testCustomer);
        Long customerId = saved.getId();

        // Act
        saved.setName("John Updated");
        saved.setAge(31);
        Customer updated = customerRepository.save(saved);
        entityManager.flush();

        // Assert
        Optional<Customer> found = customerRepository.findById(customerId);
        assertThat(found).isPresent();
        assertThat(found.get().getName()).isEqualTo("John Updated");
        assertThat(found.get().getAge()).isEqualTo(31);
    }

    @Test
    @DisplayName("Should delete customer successfully")
    void deleteCustomer_ExistingCustomer_RemovesFromDatabase() {
        // Arrange
        Customer saved = entityManager.persistAndFlush(testCustomer);
        Long customerId = saved.getId();

        // Act
        customerRepository.deleteById(customerId);
        entityManager.flush();

        // Assert
        Optional<Customer> deleted = customerRepository.findById(customerId);
        assertThat(deleted).isEmpty();
    }

    @Test
    @DisplayName("Should check if customer exists by ID")
    void existsById_ExistingCustomer_ReturnsTrue() {
        // Arrange
        Customer saved = entityManager.persistAndFlush(testCustomer);

        // Act
        boolean exists = customerRepository.existsById(saved.getId());

        // Assert
        assertThat(exists).isTrue();
    }

    @Test
    @DisplayName("Should return false for non-existing customer ID")
    void existsById_NonExistingCustomer_ReturnsFalse() {
        // Act
        boolean exists = customerRepository.existsById(999L);

        // Assert
        assertThat(exists).isFalse();
    }

    @Test
    @DisplayName("Should count all customers")
    void count_MultipleCustomers_ReturnsCorrectCount() {
        // Arrange
        Customer customer2 = new Customer(null, "Jane Doe", "jane@example.com", "9876543210", 25);
        entityManager.persistAndFlush(testCustomer);
        entityManager.persistAndFlush(customer2);

        // Act
        long count = customerRepository.count();

        // Assert
        assertThat(count).isEqualTo(2);
    }
}
