package com.example.demo;


import org.junit.jupiter.api.Test;

import com.example.demo.security.JwtUtil;

import static org.junit.jupiter.api.Assertions.*;

class JwtUtilTest {

    private final JwtUtil jwtUtil = new JwtUtil();

    @Test
    void generateToken_shouldReturnValidToken() {
        String token = jwtUtil.generateToken("ravi");

        assertNotNull(token);
        assertTrue(jwtUtil.isTokenValid(token));
    }

    @Test
    void extractUsername_shouldReturnCorrectUsername() {
        String token = jwtUtil.generateToken("ravi");

        String username = jwtUtil.extractUsername(token);

        assertEquals("ravi", username);
    }

    @Test
    void isTokenValid_shouldReturnFalseForInvalidToken() {
        String invalidToken = "invalid.jwt.token";

        boolean valid = jwtUtil.isTokenValid(invalidToken);

        assertFalse(valid);
    }

    @Test
    void extractUsername_shouldThrowExceptionForInvalidToken() {
        String invalidToken = "invalid.jwt.token";

        assertThrows(Exception.class, () ->
                jwtUtil.extractUsername(invalidToken)
        );
    }
}
