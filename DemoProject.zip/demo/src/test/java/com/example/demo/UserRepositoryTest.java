package com.example.demo;

import com.example.demo.entity.Role;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@DisplayName("User Repository Tests")
class UserRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private UserRepository userRepository;

    private User testUser;

    @BeforeEach
    void setUp() {
        // Arrange: Create test user
        testUser = new User();
        testUser.setUsername("testuser");
        testUser.setPassword("password123");
        testUser.setRole(Role.ROLE_USER);
    }

    @Test
    @DisplayName("Should save user successfully")
    void saveUser_WithValidData_ReturnsSavedUser() {
        // Act
        User saved = userRepository.save(testUser);

        // Assert
        assertThat(saved).isNotNull();
        assertThat(saved.getId()).isNotNull();
        assertThat(saved.getUsername()).isEqualTo("testuser");
        assertThat(saved.getRole()).isEqualTo(Role.ROLE_USER);
    }

    @Test
    @DisplayName("Should find user by username")
    void findByUsername_ExistingUser_ReturnsUser() {
        // Arrange
        entityManager.persistAndFlush(testUser);

        // Act
        Optional<User> found = userRepository.findByUsername("testuser");

        // Assert
        assertThat(found).isPresent();
        assertThat(found.get().getUsername()).isEqualTo("testuser");
    }

    @Test
    @DisplayName("Should return empty when username not found")
    void findByUsername_NonExistingUser_ReturnsEmpty() {
        // Act
        Optional<User> found = userRepository.findByUsername("nonexistent");

        // Assert
        assertThat(found).isEmpty();
    }

    @Test
    @DisplayName("Should check if username exists")
    void existsByUsername_ExistingUser_ReturnsTrue() {
        // Arrange
        entityManager.persistAndFlush(testUser);

        // Act
        boolean exists = userRepository.existsByUsername("testuser");

        // Assert
        assertThat(exists).isTrue();
    }

    @Test
    @DisplayName("Should return false for non-existing username")
    void existsByUsername_NonExistingUser_ReturnsFalse() {
        // Act
        boolean exists = userRepository.existsByUsername("nonexistent");

        // Assert
        assertThat(exists).isFalse();
    }

    @Test
    @DisplayName("Should find user by ID")
    void findById_ExistingUser_ReturnsUser() {
        // Arrange
        User saved = entityManager.persistAndFlush(testUser);

        // Act
        Optional<User> found = userRepository.findById(saved.getId());

        // Assert
        assertThat(found).isPresent();
        assertThat(found.get().getId()).isEqualTo(saved.getId());
    }

    @Test
    @DisplayName("Should delete user successfully")
    void deleteUser_ExistingUser_RemovesFromDatabase() {
        // Arrange
        User saved = entityManager.persistAndFlush(testUser);
        Long userId = saved.getId();

        // Act
        userRepository.deleteById(userId);
        entityManager.flush();

        // Assert
        Optional<User> deleted = userRepository.findById(userId);
        assertThat(deleted).isEmpty();
    }

    @Test
    @DisplayName("Should enforce unique username constraint")
    void saveUser_DuplicateUsername_ThrowsException() {
        // Arrange
        entityManager.persistAndFlush(testUser);

        User duplicate = new User();
        duplicate.setUsername("testuser"); // Same username
        duplicate.setPassword("different");
        duplicate.setRole(Role.ROLE_ADMIN);

        // Act & Assert
        try {
            entityManager.persistAndFlush(duplicate);
        } catch (Exception e) {
            assertThat(e).isInstanceOf(Exception.class);
        }
    }
}
