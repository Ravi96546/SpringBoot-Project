package com.example.demo;

import com.example.demo.dto.CustomerDTO;

import com.example.demo.entity.Customer;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.service.CustomerServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Customer Service Tests")
class CustomerServiceImplTest {

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerServiceImpl customerService;

    private CustomerDTO testCustomerDTO;
    private Customer testCustomer;

    @BeforeEach
    void setUp() {
        // Setup test DTO
        testCustomerDTO = new CustomerDTO();
        testCustomerDTO.setName("John Doe");
        testCustomerDTO.setEmail("john@example.com");
        testCustomerDTO.setPhone("1234567890");
        testCustomerDTO.setAge(30);

        // Setup test Entity
        testCustomer = new Customer();
        testCustomer.setId(1L);
        testCustomer.setName("John Doe");
        testCustomer.setEmail("john@example.com");
        testCustomer.setPhone("1234567890");
        testCustomer.setAge(30);
    }

    // ========================================
    // CREATE CUSTOMER TESTS
    // ========================================

    @Test
    @DisplayName("Should create customer successfully with valid data")
    void createCustomer_WithValidData_ReturnsCustomerDTO() {
        // Arrange
        when(customerRepository.save(any(Customer.class))).thenReturn(testCustomer);

        // Act
        CustomerDTO result = customerService.createCustomer(testCustomerDTO);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo("John Doe");
        assertThat(result.getEmail()).isEqualTo("john@example.com");
        assertThat(result.getAge()).isEqualTo(30);

        // Verify repository was called once
        verify(customerRepository, times(1)).save(any(Customer.class));
    }

    @Test
    @DisplayName("Should map DTO to Entity correctly during create")
    void createCustomer_MapsFieldsCorrectly() {
        // Arrange
        when(customerRepository.save(any(Customer.class))).thenReturn(testCustomer);

        // Act
        customerService.createCustomer(testCustomerDTO);

        // Assert - Verify the Entity passed to repository has correct values
        verify(customerRepository).save(argThat(customer ->
                customer.getName().equals("John Doe") &&
                customer.getEmail().equals("john@example.com") &&
                customer.getPhone().equals("1234567890") &&
                customer.getAge() == 30
        ));
    }

    // ========================================
    // UPDATE CUSTOMER TESTS
    // ========================================

    @Test
    @DisplayName("Should update customer successfully when customer exists")
    void updateCustomer_ExistingCustomer_ReturnsUpdatedDTO() {
        // Arrange
        CustomerDTO updateDTO = new CustomerDTO();
        updateDTO.setName("John Updated");
        updateDTO.setEmail("johnupdated@example.com");
        updateDTO.setPhone("9876543210");
        updateDTO.setAge(31);

        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));
        when(customerRepository.save(any(Customer.class))).thenReturn(testCustomer);

        // Act
        CustomerDTO result = customerService.updateCustomer(1L, updateDTO);

        // Assert
        assertThat(result).isNotNull();
        verify(customerRepository, times(1)).findById(1L);
        verify(customerRepository, times(1)).save(any(Customer.class));
    }

    @Test
    @DisplayName("Should throw exception when updating non-existing customer")
    void updateCustomer_NonExistingCustomer_ThrowsResourceNotFoundException() {
        // Arrange
        when(customerRepository.findById(999L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> customerService.updateCustomer(999L, testCustomerDTO))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Customer not found with id 999");

        verify(customerRepository, times(1)).findById(999L);
        verify(customerRepository, never()).save(any(Customer.class));
    }

    // ========================================
    // DELETE CUSTOMER TEST
    // ========================================

    @Test
    @DisplayName("Should delete customer successfully when customer exists")
    void deleteCustomer_ExistingCustomer_DeletesSuccessfully() {
        // Arrange
        when(customerRepository.existsById(1L)).thenReturn(true);
        doNothing().when(customerRepository).deleteById(1L);

        // Act
        customerService.deleteCustomer(1L);

        // Assert
        verify(customerRepository, times(1)).existsById(1L);
        verify(customerRepository, times(1)).deleteById(1L);
    }

    @Test
    @DisplayName("Should throw exception when deleting non-existing customer")
    void deleteCustomer_NonExistingCustomer_ThrowsResourceNotFoundException() {
        // Arrange
        when(customerRepository.existsById(999L)).thenReturn(false);

        // Act & Assert
        assertThatThrownBy(() -> customerService.deleteCustomer(999L))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Customer not found with id 999");

        verify(customerRepository, times(1)).existsById(999L);
        verify(customerRepository, never()).deleteById(anyLong());
    }

    // ========================================
    // GET ALL CUSTOMERS TESTS
    // ========================================

    @Test
    @DisplayName("Should return all customers")
    void getAllCustomers_MultipleCustomers_ReturnsListOfDTOs() {
        // Arrange
        Customer customer2 = new Customer(2L, "Jane Doe", "jane@example.com", "9876543210", 25);
        List<Customer> customers = Arrays.asList(testCustomer, customer2);

        when(customerRepository.findAll()).thenReturn(customers);

        // Act
        List<CustomerDTO> result = customerService.getAllCustomers();

        // Assert
        assertThat(result).isNotNull();
        assertThat(result).hasSize(2);
        assertThat(result.get(0).getName()).isEqualTo("John Doe");
        assertThat(result.get(1).getName()).isEqualTo("Jane Doe");

        verify(customerRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Should return empty list when no customers exist")
    void getAllCustomers_NoCustomers_ReturnsEmptyList() {
        // Arrange
        when(customerRepository.findAll()).thenReturn(Arrays.asList());

        // Act
        List<CustomerDTO> result = customerService.getAllCustomers();

        // Assert
        assertThat(result).isNotNull();
        assertThat(result).isEmpty();

        verify(customerRepository, times(1)).findAll();
    }

    // ========================================
    // GET CUSTOMER BY ID TESTS
    // ========================================

    @Test
    @DisplayName("Should return customer when ID exists")
    void getCustomerById_ExistingCustomer_ReturnsCustomerDTO() {
        // Arrange
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));

        // Act
        CustomerDTO result = customerService.getCustomerById(1L);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo("John Doe");
        assertThat(result.getEmail()).isEqualTo("john@example.com");

        verify(customerRepository, times(1)).findById(1L);
    }

    @Test
    @DisplayName("Should throw exception when customer ID not found")
    void getCustomerById_NonExistingCustomer_ThrowsResourceNotFoundException() {
        // Arrange
        when(customerRepository.findById(999L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> customerService.getCustomerById(999L))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Customer not found with id 999");

        verify(customerRepository, times(1)).findById(999L);
    }

    // ========================================
    // EDGE CASE TESTS
    // ========================================

    @Test
    @DisplayName("Should handle repository exception during create")
    void createCustomer_RepositoryThrowsException_PropagatesException() {
        // Arrange
        when(customerRepository.save(any(Customer.class)))
                .thenThrow(new RuntimeException("Database error"));

        // Act & Assert
        assertThatThrownBy(() -> customerService.createCustomer(testCustomerDTO))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Database error");
    }

    @Test
    @DisplayName("Should handle null ID gracefully")
    void getCustomerById_NullId_ThrowsException() {
        // Act & Assert
        assertThatThrownBy(() -> customerService.getCustomerById(null))
                .isInstanceOf(Exception.class);
    }
}