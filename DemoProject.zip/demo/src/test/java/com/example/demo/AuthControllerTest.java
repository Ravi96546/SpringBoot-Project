package com.example.demo;

import com.example.demo.controller.AuthController;
import com.example.demo.dto.AuthRequest;
import com.example.demo.entity.Role;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.security.JwtUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuthController.class)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AuthenticationManager authenticationManager;

    @MockBean
    private JwtUtil jwtUtil;

    @MockBean
    private UserRepository userRepository;

    @MockBean
    private PasswordEncoder passwordEncoder;

    @Test
    void login_success() throws Exception {
        AuthRequest request = new AuthRequest("ravi", "1234");

        UserDetails userDetails =
                org.springframework.security.core.userdetails.User
                        .withUsername("ravi")
                        .password("encoded")
                        .roles("USER")
                        .build();

        Authentication authentication =
                new UsernamePasswordAuthenticationToken(
                        userDetails, null, userDetails.getAuthorities());

        Mockito.when(authenticationManager.authenticate(Mockito.any()))
                .thenReturn(authentication);

        Mockito.when(jwtUtil.generateToken("ravi"))
                .thenReturn("dummy-jwt");

        User user = new User();
        user.setUsername("ravi");
        user.setRole(Role.ROLE_USER);

        Mockito.when(userRepository.findByUsername("ravi"))
                .thenReturn(Optional.of(user));

        mockMvc.perform(post("/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("dummy-jwt"))
                .andExpect(jsonPath("$.username").value("ravi"))
                .andExpect(jsonPath("$.role").value("ROLE_USER"));
    }

    @Test
    void register_success() throws Exception {
        AuthRequest request = new AuthRequest("newuser", "password");

        Mockito.when(userRepository.existsByUsername("newuser"))
                .thenReturn(false);

        Mockito.when(passwordEncoder.encode("password"))
                .thenReturn("encoded-password");

        mockMvc.perform(post("/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message")
                        .value("User registered successfully"))
                .andExpect(jsonPath("$.username")
                        .value("newuser"));
    }
}

