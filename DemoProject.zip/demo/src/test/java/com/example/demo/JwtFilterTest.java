package com.example.demo;


import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import com.example.demo.security.CustomUserDetailsService;
import com.example.demo.security.JwtFilter;
import com.example.demo.security.JwtUtil;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class JwtFilterTest {

    private JwtFilter jwtFilter;
    private JwtUtil jwtUtil;
    private CustomUserDetailsService userDetailsService;

    @BeforeEach
    void setUp() {
        jwtUtil = mock(JwtUtil.class);
        userDetailsService = mock(CustomUserDetailsService.class);

//        jwtFilter = new JwtFilter();
//        jwtFilter.jwtUtil = jwtUtil;
//        jwtFilter.userDetailsService = userDetailsService;

        SecurityContextHolder.clearContext();
    }

    @Test
    void doFilter_shouldAuthenticateUser_whenValidTokenProvided() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI("/api/customers");
        request.setMethod("GET");
        request.addHeader("Authorization", "Bearer valid-token");

        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain filterChain = mock(FilterChain.class);

        UserDetails userDetails = User.builder()
                .username("ravi")
                .password("password")
                .roles("USER")
                .build();

        when(jwtUtil.isTokenValid("valid-token")).thenReturn(true);
        when(jwtUtil.extractUsername("valid-token")).thenReturn("ravi");
        when(userDetailsService.loadUserByUsername("ravi"))
                .thenReturn(userDetails);

        jwtFilter.doFilter(request, response, filterChain);

        assertNotNull(SecurityContextHolder.getContext().getAuthentication());
        assertEquals("ravi",
                SecurityContextHolder.getContext()
                        .getAuthentication()
                        .getName());

        verify(filterChain, times(1))
                .doFilter(request, response);
    }

    @Test
    void doFilter_shouldNotAuthenticate_whenNoTokenProvided() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI("/api/customers");
        request.setMethod("GET");

        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain filterChain = mock(FilterChain.class);

        jwtFilter.doFilter(request, response, filterChain);

        assertNull(SecurityContextHolder.getContext().getAuthentication());

        verify(filterChain, times(1))
                .doFilter(request, response);
    }
}
