package com.example.demo;

import com.example.demo.controller.CustomerController;
import com.example.demo.dto.CustomerDTO;
import com.example.demo.service.CustomerService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CustomerController.class)
class CustomerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private CustomerService customerService;

    @Test
    @WithMockUser(roles = "ADMIN")
    void createCustomer_success() throws Exception {
        CustomerDTO dto = new CustomerDTO();
        dto.setName("Ravi");
        dto.setEmail("ravi@gmail.com");
        dto.setPhone("9999999999");
        dto.setAge(25);

        Mockito.when(customerService.createCustomer(Mockito.any()))
                .thenReturn(dto);

        mockMvc.perform(post("/api/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Ravi"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN", "USER"})
    void getAllCustomers_success() throws Exception {
        CustomerDTO dto = new CustomerDTO();
        dto.setName("Ravi");

        Mockito.when(customerService.getAllCustomers())
                .thenReturn(List.of(dto));

        mockMvc.perform(get("/api/customers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Ravi"));
    }

    @Test
    @WithMockUser(roles = {"ADMIN", "USER"})
    void getCustomerById_success() throws Exception {
        CustomerDTO dto = new CustomerDTO();
        dto.setName("Ravi");

        Mockito.when(customerService.getCustomerById(1L))
                .thenReturn(dto);

        mockMvc.perform(get("/api/customers/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Ravi"));
    }
}

