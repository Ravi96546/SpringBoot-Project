package com.example.demo.controller;
import com.example.demo.dto.CustomerDTO;
import com.example.demo.service.CustomerService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

    @Autowired
    private CustomerService service;

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<CustomerDTO> createCustomer(@Valid @RequestBody CustomerDTO dto) {
        logger.info(" CREATE Customer request - Name: {}, Email: {}", dto.getName(), dto.getEmail());
        
        try {
            CustomerDTO created = service.createCustomer(dto);
            logger.info(" Customer created successfully - Name: {}", created.getName());
            return ResponseEntity.ok(created);
        } catch (Exception e) {
            logger.error(" Failed to create customer - Name: {}, Error: {}", dto.getName(), e.getMessage(), e);
            throw e;
        }
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    @GetMapping
    public ResponseEntity<List<CustomerDTO>> getAllCustomers() {
        logger.info(" GET All Customers request");
        
        try {
            List<CustomerDTO> customers = service.getAllCustomers();
            logger.info(" Fetched {} customers", customers.size());
            return ResponseEntity.ok(customers);
        } catch (Exception e) {
            logger.error(" Failed to fetch customers: {}", e.getMessage(), e);
            throw e;
        }
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    @GetMapping("/{id}")
    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable Long id) {
        logger.info(" GET Customer by ID request - ID: {}", id);
        
        try {
            CustomerDTO customer = service.getCustomerById(id);
            logger.info(" Customer found - ID: {}, Name: {}", id, customer.getName());
            return ResponseEntity.ok(customer);
        } catch (Exception e) {
            logger.error(" Customer not found - ID: {}, Error: {}", id, e.getMessage());
            throw e;
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<CustomerDTO> updateCustomer(
            @PathVariable Long id,
            @Valid @RequestBody CustomerDTO dto) {
        logger.info(" UPDATE Customer request - ID: {}, New Name: {}", id, dto.getName());
        
        try {
            CustomerDTO updated = service.updateCustomer(id, dto);
            logger.info(" Customer updated successfully - ID: {}", id);
            return ResponseEntity.ok(updated);
        } catch (Exception e) {
            logger.error(" Failed to update customer - ID: {}, Error: {}", id, e.getMessage(), e);
            throw e;
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteCustomer(@PathVariable Long id) {
        logger.warn(" DELETE Customer request - ID: {}", id);
        
        try {
            service.deleteCustomer(id);
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "Customer deleted successfully");
            response.put("id", id.toString());
            
            logger.info(" Customer deleted successfully - ID: {}", id);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error(" Failed to delete customer - ID: {}, Error: {}", id, e.getMessage(), e);
            throw e;
        }
    }
}