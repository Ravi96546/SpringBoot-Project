


package com.example.demo.service;

import com.example.demo.dto.CustomerDTO;
import com.example.demo.entity.Customer;
import com.example.demo.repository.CustomerRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {

    private static final Logger logger = LoggerFactory.getLogger(CustomerServiceImpl.class);

    @Autowired
    private CustomerRepository repository;

    @Override
    public CustomerDTO createCustomer(CustomerDTO dto) {
        logger.debug("Service: Creating customer - Name: {}, Email: {}", dto.getName(), dto.getEmail());
        
        try {
            Customer customer = new Customer();
            customer.setName(dto.getName());
            customer.setEmail(dto.getEmail());
            customer.setPhone(dto.getPhone());
            customer.setAge(dto.getAge());

            logger.trace("Mapped DTO to Entity - Customer: {}", customer);
            
            Customer saved = repository.save(customer);
            logger.debug("Customer saved to database - ID: {}", saved.getId());

            CustomerDTO result = mapToDTO(saved);
            logger.info("Service: Customer created successfully - ID: {}, Name: {}", saved.getId(), saved.getName());
            
            return result;
        } catch (Exception e) {
            logger.error(" Service: Failed to create customer - Error: {}", e.getMessage(), e);
            throw e;
        }
    }

    @Override
    public CustomerDTO updateCustomer(Long id, CustomerDTO dto) {
        logger.debug("Service: Updating customer - ID: {}", id);
        
        try {
            Customer customer = repository.findById(id)
                    .orElseThrow(() -> {
                        logger.error(" Customer not found - ID: {}", id);
                        return new RuntimeException("Customer not found with id " + id);
                    });

            logger.trace("Found customer - Current Name: {}, New Name: {}", customer.getName(), dto.getName());
            
            customer.setName(dto.getName());
            customer.setEmail(dto.getEmail());
            customer.setPhone(dto.getPhone());
            customer.setAge(dto.getAge());

            Customer updated = repository.save(customer);
            logger.debug("Customer updated in database - ID: {}", id);

            CustomerDTO result = mapToDTO(updated);
            logger.info("Service: Customer updated successfully - ID: {}", id);
            
            return result;
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            logger.error("Service: Failed to update customer - ID: {}, Error: {}", id, e.getMessage(), e);
            throw e;
        }
    }

    @Override
    public void deleteCustomer(Long id) {
        logger.debug("Service: Deleting customer - ID: {}", id);
        
        try {
            if (!repository.existsById(id)) {
                logger.error(" Customer not found for deletion - ID: {}", id);
                throw new RuntimeException("Customer not found with id " + id);
            }
            
            repository.deleteById(id);
            logger.info(" Service: Customer deleted successfully - ID: {}", id);
            
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            logger.error(" Service: Failed to delete customer - ID: {}, Error: {}", id, e.getMessage(), e);
            throw e;
        }
    }

    @Override
    public List<CustomerDTO> getAllCustomers() {
        logger.debug("Service: Fetching all customers");
        
        try {
            List<Customer> customers = repository.findAll();
            logger.trace("Found {} customers in database", customers.size());
            
            List<CustomerDTO> result = customers.stream()
                    .map(this::mapToDTO)
                    .collect(Collectors.toList());
            
            logger.info(" Service: Fetched {} customers successfully", result.size());
            return result;
            
        } catch (Exception e) {
            logger.error(" Service: Failed to fetch customers - Error: {}", e.getMessage(), e);
            throw e;
        }
    }

    @Override
    public CustomerDTO getCustomerById(Long id) {
        logger.debug("Service: Fetching customer by ID - ID: {}", id);
        
        try {
            Customer customer = repository.findById(id)
                    .orElseThrow(() -> {
                        logger.error(" Customer not found - ID: {}", id);
                        return new RuntimeException("Customer not found with id " + id);
                    });
            
            CustomerDTO result = mapToDTO(customer);
            logger.info("Service: Customer found - ID: {}, Name: {}", id, customer.getName());
            
            return result;
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            logger.error("Service: Failed to fetch customer - ID: {}, Error: {}", id, e.getMessage(), e);
            throw e;
        }
    }

    private CustomerDTO mapToDTO(Customer customer) {
        logger.trace("Mapping Entity to DTO - Customer ID: {}", customer.getId());
        
        CustomerDTO dto = new CustomerDTO();
        dto.setId(customer.getId());
        dto.setName(customer.getName());
        dto.setEmail(customer.getEmail());
        dto.setPhone(customer.getPhone());
        dto.setAge(customer.getAge());
        
        return dto;
    }
}