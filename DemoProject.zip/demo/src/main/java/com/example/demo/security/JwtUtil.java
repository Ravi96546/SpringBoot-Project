
package com.example.demo.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {

    private static final Logger logger = LoggerFactory.getLogger(JwtUtil.class);

    private final String SECRET = "jwt-secret-key-1234567890-must-be-at-least-256-bits-long";
    private final long EXPIRATION_TIME = 86400000; 

    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(SECRET.getBytes());
    }

    public String generateToken(String username) {
        logger.debug(" Generating JWT token for user: {}", username);
        
        try {
            String token = Jwts.builder()
                    .setSubject(username)
                    .setIssuedAt(new Date())
                    .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                    .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                    .compact();
            
            logger.info(" JWT token generated successfully for user: {}", username);
            logger.trace("Token: {}...", token.substring(0, Math.min(20, token.length())));
            
            return token;
        } catch (Exception e) {
            logger.error("Failed to generate JWT token for user: {}", username, e);
            throw e;
        }
    }

    public String extractUsername(String token) {
        logger.trace("Extracting username from JWT token");
        
        try {
            String username = getClaims(token).getSubject();
            logger.debug(" Username extracted from token: {}", username);
            return username;
        } catch (Exception e) {
            logger.error(" Failed to extract username from token: {}", e.getMessage());
            throw e;
        }
    }

    public boolean isTokenValid(String token) {
        logger.trace("Validating JWT token");
        
        try {
            boolean valid = !isTokenExpired(token);
            if (valid) {
                logger.debug(" Token is valid");
            } else {
                logger.warn(" Token is expired");
            }
            return valid;
        } catch (Exception e) {
            logger.error(" Token validation failed: {}", e.getMessage());
            return false;
        }
    }

    private boolean isTokenExpired(String token) {
        Date expiration = getClaims(token).getExpiration();
        boolean expired = expiration.before(new Date());
        
        if (expired) {
            logger.debug("Token expired at: {}", expiration);
        }
        
        return expired;
    }

    private Claims getClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }
}