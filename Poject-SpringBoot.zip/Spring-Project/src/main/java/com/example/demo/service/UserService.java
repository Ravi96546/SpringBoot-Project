package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository repo;

    public User createUser(User user) {

        if (!user.getName().matches("[A-Za-z ]+")) {
            throw new RuntimeException("Invalid Name");
        }

        if (user.getAge() < 20 || user.getAge() > 60) {
            throw new RuntimeException("Invalid Age");
        }

        String desig = user.getDesignation();

        if (desig.equalsIgnoreCase("Programmer")) {
            user.setSalary(20000);
            user.setDesignation("PROGRAMMER");
        } else if (desig.equalsIgnoreCase("Manager")) {
            user.setSalary(25000);
            user.setDesignation("MANAGER");
        } else if (desig.equalsIgnoreCase("Testing")) {
            user.setSalary(15000);
            user.setDesignation("TESTING");
        } else {
            throw new RuntimeException("Invalid Designation");
        }

        return repo.save(user);
    }

    public List<User> getAllUsers() {
        return repo.findAll();
    }

    public User updateUser(Long id, User user) {
        User u = repo.findById(id).orElseThrow();
        u.setName(user.getName());
        u.setAge(user.getAge());
        u.setDesignation(user.getDesignation());
        return createUser(u);
    }

    public void deleteUser(Long id) {
        repo.deleteById(id);
    }

    public void raiseSalary(double amount) {
        List<User> list = repo.findAll();
        for (User u : list) {
            u.setSalary(u.getSalary() + amount);
            repo.save(u);
        }
    }
}