package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.User;
import com.example.demo.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService service;

    // POST - Create User
    @PostMapping
    public User createUser(@RequestBody User user) {
        return service.createUser(user);
    }

    // GET - All Users
    @GetMapping
    public List<User> getUsers() {
        return service.getAllUsers();
    }

    // PUT - Update User
    @PutMapping("/{id}")
    public User updateUser(@PathVariable Long id, @RequestBody User user) {
        return service.updateUser(id, user);
    }

    // DELETE - Delete User
    @DeleteMapping("/{id}")
    public String deleteUser(@PathVariable Long id) {
        service.deleteUser(id);
        return "User Deleted Successfully";
    }

    // PUT - Raise Salary
    @PutMapping("/raise/{amount}")
    public String raiseSalary(@PathVariable double amount) {
        service.raiseSalary(amount);
        return "Salary Updated";
    }
}