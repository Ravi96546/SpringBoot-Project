package com.example.demo.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.Model.Employee;
import com.example.demo.Repository.EmployeeRepository;

@Service
public class EmployeeService {

    private final EmployeeRepository repo;

    public EmployeeService(EmployeeRepository repo) {
        this.repo = repo;
    }

    public Employee save(Employee e) {
        switch (e.getDesignation().toLowerCase()) {
            case "programmer" -> e.setSalary(20000);
            case "manager" -> e.setSalary(25000);
            case "tester" -> e.setSalary(15000);
            default -> e.setSalary(0);
        }
        return repo.save(e);
    }

    public List<Employee> findAll() {
        return repo.findAll();
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }

    public void raiseSalary(Long id, int percent) {
        Employee e = repo.findById(id).orElse(null);
        if (e != null && percent >= 1 && percent <= 10) {
            e.setSalary(e.getSalary() + (e.getSalary() * percent / 100));
            repo.save(e);
        }
    }
}
