package com.example.demo.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ✔ Only alphabets, max 3 spaces
    @NotBlank(message = "Name is required")
    @Pattern(
        regexp = "^[A-Za-z]+( [A-Za-z]+){0,3}$",
        message = "Name must contain only letters and max 3 spaces"
    )
    private String name;

    // ✔ Age between 20 and 60
    @Min(value = 20, message = "Age must be at least 20")
    @Max(value = 60, message = "Age must not exceed 60")
    private int age;

    // ✔ Only allowed values
    @NotBlank(message = "Designation is required")
    @Pattern(
        regexp = "programmer|manager|tester",
        flags = Pattern.Flag.CASE_INSENSITIVE,
        message = "Designation must be programmer, manager, or tester"
    )
    private String designation;

    private double salary;

    public Employee() {}

    // getters & setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }

    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }
}
