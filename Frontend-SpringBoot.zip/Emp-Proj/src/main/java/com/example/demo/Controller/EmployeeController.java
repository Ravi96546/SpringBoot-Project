package com.example.demo.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Model.Employee;
import com.example.demo.Service.EmployeeService;

import jakarta.validation.Valid;

@Controller
public class EmployeeController {

    private final EmployeeService service;

    public EmployeeController(EmployeeService service) {
        this.service = service;
    }

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("employee", new Employee());
        return "add-employee";
    }

    @PostMapping("/save")
    public String save(
            @Valid @ModelAttribute Employee employee,
            BindingResult result,
            Model model) {

        if (result.hasErrors()) {
            return "add-employee";
        }

        service.save(employee);
        return "redirect:/";
    }


    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("employees", service.findAll());
        return "list-employees";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        service.delete(id);
        return "redirect:/index";
    }

    @GetMapping("/raise-salary")
    public String raiseSalaryPage() {
        return "raise-salary";
    }

    @PostMapping("/raise-salary")
    public String raiseSalary(@RequestParam Long id,
                              @RequestParam int percentage) {
        service.raiseSalary(id, percentage);
        return "redirect:/index";
    }
}
