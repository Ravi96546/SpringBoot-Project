package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "user_table")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    private int age;
    private double salary;
    private String designation;

    public User() {}

    public User(String name, int age) {
        this.name = name;
        this.age = age;
        this.salary = 0;
    }

    // getters & setters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    
    public String getDesignation() {
    	return designation;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    
    public void setDesignation(String designation) {
    	this.designation=designation;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}
