package com.example.demo;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;
import java.util.Scanner;

@SpringBootApplication
public class Demo1Application implements CommandLineRunner {

    @Autowired
    private UserRepository repo;

    Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        SpringApplication.run(Demo1Application.class, args);
    }

    @Override
    public void run(String... args) {

        int option;

        do {
            System.out.println("\n MENU");
            System.out.println("1. Create User");
            System.out.println("2. Display Users");
            System.out.println("3. Raise Salary");
            System.out.println("4. Exit");

            System.out.print("Enter option: ");
            option = sc.nextInt();

            switch (option) {

                case 1:
                    createUser();
                    break;

                case 2:
                    displayUsers();
                    break;

                case 3:
                    raiseSalary();
                    break;

                case 4:
                    System.out.println("Thank You! Program Ended.");
                    break;

                default:
                    System.out.println("Invalid Option!");
            }

        } while (option != 4);
    }

    void createUser() {
    	
    	sc.nextLine();
        System.out.print("Enter name: ");
        
        String name = sc.nextLine();
        
        if(!name.matches("[A-Za-z ]+")) {
        	System.out.println("Invalid Name ! Only two spaces allowed.");
        	return;
        }

        System.out.print("Enter age: ");
        int age = sc.nextInt();
        
        if(age<20 || age>60) {
        	System.out.println("Invalid Age! Age must be between 20 and 60.");
        	return;
        }
        sc.nextLine();
        
        System.out.print("Enter Destination: ");
        String desig= sc.nextLine();
        
        double salary ;
        
        if(desig.equalsIgnoreCase("Programmer")) {
        	salary=20000;
        	desig="PROGRAMMER";
        }
        
        else if(desig.equalsIgnoreCase("Manager")) {
        	salary=25000;
        	desig="MANAGER";
        }
        
        else if(desig.equalsIgnoreCase("Testing")) {
        	salary=15000;
        	desig="TESTING";
        }
        
        else {
        	salary=0;
        	System.out.print("Invalid Designation!");
        }
        
        User user = new User(name, age);
        user.setDesignation(desig);
        user.setSalary(salary);
        repo.save(user);
        System.out.println("User Saved Successfully with salary: "+ salary);
    }

    void displayUsers() {

        List<User> list = repo.findAll();

        if (list.isEmpty()) {
            System.out.println("No Records Found!");
            return;
        }

        for (User u : list) {
            System.out.println(
                    "ID: " + u.getId() +
                    ", Name: " + u.getName() +
                    ", Age: " + u.getAge() +
                    ", Designation: " + u.getDesignation() +
                    ", Salary: " + u.getSalary()
            );
        }
    }
    void raiseSalary() {
        System.out.print("Enter salary increment: ");
        double amount = sc.nextDouble();

        List<User> list = repo.findAll();

        for (User u : list) {
            u.setSalary(u.getSalary() + amount);
            repo.save(u);
        }

        System.out.println("Salary Updated Successfully");
    }
}


